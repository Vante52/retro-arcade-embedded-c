CMakeFiles/tetris_core.dir/core/bag.c.o: \
 /home/valkyrie/dotfiles/Documents/PUJ/sem7/dispro/retro-arcade-embedded-c/tetris/core/bag.c \
 /usr/include/stdc-predef.h \
 /home/valkyrie/dotfiles/Documents/PUJ/sem7/dispro/retro-arcade-embedded-c/tetris/core/bag.h \
 /usr/lib/gcc/x86_64-linux-gnu/13/include/stdint.h /usr/include/stdint.h \
 /usr/include/x86_64-linux-gnu/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/x86_64-linux-gnu/bits/wordsize.h \
 /usr/include/x86_64-linux-gnu/bits/timesize.h \
 /usr/include/x86_64-linux-gnu/sys/cdefs.h \
 /usr/include/x86_64-linux-gnu/bits/long-double.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs-64.h \
 /usr/include/x86_64-linux-gnu/bits/types.h \
 /usr/include/x86_64-linux-gnu/bits/typesizes.h \
 /usr/include/x86_64-linux-gnu/bits/time64.h \
 /usr/include/x86_64-linux-gnu/bits/wchar.h \
 /usr/include/x86_64-linux-gnu/bits/stdint-intn.h \
 /usr/include/x86_64-linux-gnu/bits/stdint-uintn.h \
 /usr/include/x86_64-linux-gnu/bits/stdint-least.h \
 /home/valkyrie/dotfiles/Documents/PUJ/sem7/dispro/retro-arcade-embedded-c/tetris/core/piece.h
