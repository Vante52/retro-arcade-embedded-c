# Empty compiler generated dependencies file for tetris_terminal.
# This may be replaced when dependencies are built.
