# Empty compiler generated dependencies file for tetris_sdl.
# This may be replaced when dependencies are built.
