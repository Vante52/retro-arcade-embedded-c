CMakeFiles/tetris_sdl.dir/main_sdl.c.o: \
 /home/valkyrie/dotfiles/Documents/PUJ/sem7/dispro/retro-arcade-embedded-c/tetris/main_sdl.c \
 /usr/include/stdc-predef.h \
 /home/valkyrie/dotfiles/Documents/PUJ/sem7/dispro/retro-arcade-embedded-c/tetris/host/sdl/main_sdl.h
